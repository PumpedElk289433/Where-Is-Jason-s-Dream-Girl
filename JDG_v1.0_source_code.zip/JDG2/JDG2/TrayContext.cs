using System.Diagnostics;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace JDG2;

public class TrayContext : ApplicationContext
{
    private NotifyIcon trayIcon;
    private BackupService backup;

    public TrayContext()
    {
        Startup.Enable();

        backup = new BackupService();

        var menu = new ContextMenuStrip();

        menu.Items.Add("查看日志", null, (s, e) =>
        {
            Process.Start("notepad.exe", Config.LogPath);
        });

        menu.Items.Add("退出", null, (s, e) =>
        {
            trayIcon.Visible = false;
            Application.Exit();
        });

        trayIcon = new NotifyIcon()
        {
            Text = "JDG2",
            Icon = SystemIcons.Application,
            ContextMenuStrip = menu,
            Visible = true
        };

        trayIcon.DoubleClick += (s, e) =>
        {
            Process.Start("notepad.exe", Config.LogPath);
        };

        UsbWatcher.Start(backup);
    }
}