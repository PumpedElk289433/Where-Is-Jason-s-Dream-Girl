using Microsoft.Win32;
using System.Windows.Forms;

namespace JDG2;

public static class Startup
{
    public static void Enable()
    {
        string exe = Application.ExecutablePath;

        var key = Registry.CurrentUser.OpenSubKey(
            @"Software\Microsoft\Windows\CurrentVersion\Run", true);

        key.SetValue("JDG2", exe);
    }
}