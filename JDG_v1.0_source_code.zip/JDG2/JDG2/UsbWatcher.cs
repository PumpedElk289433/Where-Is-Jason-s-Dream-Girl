using System.Management;

namespace JDG2;

public static class UsbWatcher
{
    public static void Start(BackupService backup)
    {
        var query = new WqlEventQuery(
            "SELECT * FROM Win32_VolumeChangeEvent WHERE EventType = 2");

        var watcher = new ManagementEventWatcher(query);

        watcher.EventArrived += (s, e) =>
        {
            var drive = e.NewEvent.Properties["DriveName"]?.Value?.ToString();

            if (!string.IsNullOrEmpty(drive))
            {
                Task.Run(async () =>
                {
                    // 等待系统挂载文件系统
                    await Task.Delay(2000);

                    backup.ScanDrive(drive);
                });
            }
        };

        watcher.Start();
    }
}