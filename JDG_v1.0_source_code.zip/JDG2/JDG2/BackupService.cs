using System.IO;

namespace JDG2;

public class BackupService
{
    static HashSet<string> scannedDrives = new();

    public void ScanDrive(string drive)
    {
        try
        {
            var info = new DriveInfo(drive);

            // 设备未就绪
            if (!info.IsReady)
                return;

            // 只扫描U盘
            if (info.DriveType != DriveType.Removable)
                return;

            lock (scannedDrives)
            {
                if (scannedDrives.Contains(drive))
                    return;

                scannedDrives.Add(drive);
            }

            Logger.Log("Scan start: " + drive);

            var opt = new EnumerationOptions
            {
                RecurseSubdirectories = true,
                IgnoreInaccessible = true,
                ReturnSpecialDirectories = false
            };

            foreach (var file in Directory.EnumerateFiles(drive, "*.xls*", opt))
            {
                // 跳过系统目录
                if (file.Contains("System Volume Information"))
                    continue;

                if (file.Contains("$RECYCLE.BIN"))
                    continue;

                Backup(file);
            }

            Logger.Log("Scan finished: " + drive);
        }
        catch (Exception ex)
        {
            Logger.Log("Error: " + ex.Message);
        }
    }

    void Backup(string source)
    {
        try
        {
            Directory.CreateDirectory(Config.BackupDir);

            var dest = Path.Combine(
                Config.BackupDir,
                Path.GetFileName(source));

            if (!File.Exists(dest) ||
                File.GetLastWriteTime(source) > File.GetLastWriteTime(dest))
            {
                File.Copy(source, dest, true);

                Logger.Log("Backup: " + source);
            }
        }
        catch (Exception ex)
        {
            Logger.Log("Backup error: " + ex.Message);
        }
    }
}