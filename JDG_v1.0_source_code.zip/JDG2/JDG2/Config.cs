namespace JDG2;

public static class Config
{
    public static string BaseDir =
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "JDG2");

    public static string BackupDir =
        Path.Combine(BaseDir, "Backup");

    public static string LogPath =
        Path.Combine(BaseDir, "log.txt");
}