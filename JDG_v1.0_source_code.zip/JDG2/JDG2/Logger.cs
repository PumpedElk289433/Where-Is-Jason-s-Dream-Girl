using System.IO;

namespace JDG2;

public static class Logger
{
    public static void Log(string msg)
    {
        Directory.CreateDirectory(Config.BackupDir);

        if (File.Exists(Config.LogPath))
        {
            if (new FileInfo(Config.LogPath).Length > 2000000)
                File.Delete(Config.LogPath);
        }

        File.AppendAllText(
            Config.LogPath,
            $"{DateTime.Now} {msg}\n");
    }
}